@echo off
"%~dp0installs.exe" -c "%~dp0License.lic" -e "%~dp0lmgrd.exe" -l "%~dp0HSM.log" -n "HSM"
net start "HSM"
pause